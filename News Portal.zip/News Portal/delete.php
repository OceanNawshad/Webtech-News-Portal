<?php
	
	session_start();
?>
<?php

//including the database connection file
    include("config.php");
    //connect_db();
//getting id of the data from url
    $id = $_GET['id'];
	
//deleting the row from table // actually not deleting it just unlinking from the result
	//$statement=
    $result = mysqli_query($conn,"update test SET Deletethis=now() WHERE id='$id';");
	//close_db();
//redirecting to the display page (listdata.php in our case)
    header("Location:listdata.php");
	
	mysql_close($conn);

?>

