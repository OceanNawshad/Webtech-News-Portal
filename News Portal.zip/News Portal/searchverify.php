<?php
	
	require 'config.php';
	
	$search=$_GET['search'];
	
	<script language="Javascript">

function postRequest(strURL) 
{
	var xmlHttp;
    if (window.XMLHttpRequest) // Mozilla, Safari, ...
    { 
        var xmlHttp = new XMLHttpRequest();
    } 
    else if (window.ActiveXObject) // IE 
    { 
         var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else
	{
		alert("your browser does not support AJAX");
		return;
	}
    xmlHttp.open('POST', strURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttp.onreadystatechange = function() 
    {
        
        if (xmlHttp.readyState == 4) 
        {
            updatepage(xmlHttp.responseText);
        }
    }
    xmlHttp.send(strURL);
}
function updatepage(str)
{
    document.getElementById("result").innerHTML = 	"<font color='red' size='5'>" + str + "</font>";
}
function show()
{
    var div=document.getElementById("result");
	div.innerHTML = '<img src="loader.gif" /> ';
	var rnd = Math.random();
	var url="ajax.php?id="+rnd;
	postRequest(url);
}

?>