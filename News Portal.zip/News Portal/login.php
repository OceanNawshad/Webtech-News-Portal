
<?php
	
	session_start();
?>
<!doctype html>
<html>
	<head>
		<title>Login Form</title>
	</head>
	
	<body>
		<br>
		<br>
		<br>
		<br>
		
		<h2 align=center>Login</h2>
		
		<form name="loginForm" method="post" action="loginverify.php">
			 <table align=center>
				<tr >
					<th>User Name</th>
					<th>:</th>
					<th><input type="text" name="UserName" ><br></th>
					
				
					
					
					<td></td>
			
				</tr>
				
				<tr>
					<th>Password</th>
					<th>:</th>
					<th><input type="password" name="Password"><br></th>
					
						
					
					
					<td></td>
			
				</tr>
				
				
			 </table>
			 
			 <table align=center>
				<tr>
					<th></th>
					<th ><br><input type="submit" value="Submit"></th>
					<th><br><a href="registration.php">Registration</a>	</th>
				</tr>
				
				<tr>
					<th></th>
					<th ><br>OR</th>
					<th>	</th>
				</tr>
				
				
				
				
			 </table>
			 
			 <table align=center>
				<tr>
					<th><img src="log in with facebook button.png" alt="Unknown error"></th>
					
				</tr>
				
				<tr>
					<th><img src="sign-in-with-google.png" alt="Unknown error" style="width:350px;height:117px;"></th>
					
				</tr>
			 </table>
			 
						 
				
			
		</form>
	</body>
</html>