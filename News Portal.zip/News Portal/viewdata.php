<?php
	session_start();
	//require_once('authenticate.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>News Site</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
	
	<style>
	ul1 {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 20px;
    background-color: #f1f1f1;
}

li1 a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

/* Change the link color on hover */
li1 a:hover {
    background-color: #555;
    color: white;
}
	</style>
	



</head>
<body>


<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">News Site</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="login.php">Insert Data</a></li>
            <li class="active"><a href="viewdata.php">View data</a></li>
            <li><a href="listdata.php">List Data</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="registration.php">Registration</a></li>
        </ul>
    </div>
</nav>






	<div class="vertical navbar default">
		<ul class="vertical nav">
	
			<li1><a href="viewdata.php">View Data</a></li>
			<li1><a href="listdata.php">List Data</a></li>
			<li1><a href="login.php">Login</a></li>
			<li1><a href="registration.php">registration</a></li>
		</ul>
	</div>


<div class="container">
        <?php
            require 'config.php';

            $statement="select * from test order by id desc";
            $result = mysqli_query($conn, $statement);

            if (mysqli_num_rows($result) > 0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
					
						echo "<div class='col-md-4'><div class='panel-group'><div class='panel panel-info'><div style='height:50px' class='panel-heading'><b>"."<a href=\"singleview.php?id=$row[id]\" class='text-warning'>".$row['heading']."</a></b> -By Admin at " .$row['datetime']."</div><div style='height:50px; overflow:hidden' class='panel-body'>".$row['summertext'] ."</div></div></div></div>";
					
                }
            }
            else
            {
                echo "Nothing found in db";
            }
            mysqli_close($conn);
        ?>
</div>
	<button>Load More</button>

</body>
</html>